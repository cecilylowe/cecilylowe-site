
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/submission-created.mjs
import { getStore } from "@netlify/blobs";
var TO = "cecily.lowe@yale.edu";
var FROM = "Newsletter <onboarding@resend.dev>";
var when = (iso) => new Date(iso).toLocaleString("en-US", {
  timeZone: "America/New_York",
  month: "short",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit"
});
var submission_created_default = async (req) => {
  const { payload } = await req.json();
  if (payload?.form_name !== "newsletter") return new Response("not the newsletter form");
  const email = String(payload.data?.email || "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return new Response("no email");
  const store = getStore("newsletter");
  const list = await store.get("subscribers", { type: "json" }) || [];
  if (list.some((s) => s.email === email)) return new Response("already subscribed");
  const at = payload.created_at || (/* @__PURE__ */ new Date()).toISOString();
  list.push({ email, at });
  await store.setJSON("subscribers", list);
  const key = process.env.RESEND_API_KEY;
  if (!key) return new Response("saved; no RESEND_API_KEY, so no email");
  const recent = [...list].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 10);
  const lines = recent.map((s, i) => `${String(i + 1).padStart(2, " ")}. ${s.email}  (${when(s.at)})`);
  const text = `${email} joined your newsletter on ${when(at)}.

Most recent sign-ups (${list.length} in total):

` + lines.join("\n") + "\n";
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: FROM, to: [TO], subject: `${email} joined your newsletter`, text })
  });
  return new Response(res.ok ? "sent" : `email failed: ${res.status} ${await res.text()}`);
};
export {
  submission_created_default as default
};
