
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/submission-created.mjs
import { getStore } from "@netlify/blobs";
import nodemailer from "nodemailer";
var TO = "cecily.lowe@yale.edu";
var when = (iso) => new Date(iso).toLocaleString("en-US", {
  timeZone: "America/New_York",
  month: "short",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit"
});
var submission_created_default = async (req) => {
  const { payload } = await req.json();
  if (payload?.form_name !== "newsletter") return new Response("not the newsletter form");
  const email = String(payload.data?.email || "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return new Response("no email");
  const store = getStore("newsletter");
  const list = await store.get("subscribers", { type: "json" }) || [];
  if (list.some((s) => s.email === email)) return new Response("already subscribed");
  const at = payload.created_at || (/* @__PURE__ */ new Date()).toISOString();
  list.push({ email, at });
  await store.setJSON("subscribers", list);
  const user = process.env.GMAIL_USER, pass = process.env.GMAIL_APP_PASSWORD;
  if (!user || !pass) return new Response("saved; Gmail not configured, so no email");
  const recent = [...list].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 10);
  const lines = recent.map((s, i) => `${String(i + 1).padStart(2, " ")}. ${s.email}  (${when(s.at)})`);
  const text = `${email} joined your newsletter on ${when(at)}.

${list.length} ${list.length === 1 ? "person" : "people"} total

` + lines.join("\n") + "\n";
  const html = emailHtml({ email, at, recent, total: list.length });
  const mail = nodemailer.createTransport({ host: "smtp.gmail.com", port: 465, secure: true, auth: { user, pass } });
  await mail.sendMail({ from: `Cecily Lowe <${process.env.MAIL_FROM || user}>`, to: TO, subject: `${email} joined your newsletter`, text, html });
  return new Response("sent");
};
var esc = (v) => String(v).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
function emailHtml({ email, at, recent, total }) {
  const font = "font-family:Helvetica,Arial,sans-serif;";
  const rows = recent.map((s, i) => `
          <tr>
            <td style="${font}font-size:14px;line-height:20px;color:#999;padding:7px 12px 7px 0;border-top:1px solid #e6e6e6;width:24px;vertical-align:top;">${i + 1}</td>
            <td style="${font}font-size:14px;line-height:20px;color:#111;padding:7px 12px 7px 0;border-top:1px solid #e6e6e6;vertical-align:top;">${esc(s.email)}</td>
            <td style="${font}font-size:13px;line-height:20px;color:#999;padding:7px 0;border-top:1px solid #e6e6e6;text-align:right;white-space:nowrap;vertical-align:top;">${esc(when(s.at))}</td>
          </tr>`).join("");
  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light only"><title>${esc(email)} joined your newsletter</title></head>
<body style="margin:0;padding:0;background:#ffffff;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#ffffff;">
    <tr><td align="left" style="padding:40px 24px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:520px;">
        <tr><td style="${font}font-size:20px;line-height:26px;color:#111;padding-bottom:6px;">${esc(email)}</td></tr>
        <tr><td style="${font}font-size:14px;line-height:20px;color:#555;padding-bottom:36px;">joined your newsletter on ${esc(when(at))}.</td></tr>
        <tr><td style="${font}font-size:13px;line-height:18px;color:#999;padding-bottom:10px;">${total} ${total === 1 ? "person" : "people"} total</td></tr>
        <tr><td>
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">${rows}
          </table>
        </td></tr>
        <tr><td style="${font}font-size:12px;line-height:18px;color:#bbb;padding-top:36px;">cecilylowe.com</td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
export {
  submission_created_default as default,
  emailHtml
};
